package com.usta_backend.model;

public enum Role {
    EXECUTOR,
    CLIENT,
    ADMIN
}
